import FCMchat as fcm

tokens = ["c0aqfxE7TTezKgnv0aMTtV:APA91bE93lbBxkCrHNDQcaeb5n9BTcKDE6tagYDBrm2t8Y7psCeBs5HJ5G9RQuuYcM-rGcUSjUNRuidzw_vWFJJ1uyISPmP2wuxrkTGCpdPfw0rTCTozEIZ9VsDLClte3fMZwyFDqSux"]

fcm.sendPush("Hi", "Ride Share API Messages 2", tokens)
